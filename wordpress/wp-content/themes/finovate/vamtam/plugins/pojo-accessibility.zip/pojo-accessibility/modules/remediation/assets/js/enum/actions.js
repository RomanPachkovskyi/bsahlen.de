export const Actions = {
	add: 'add',
	update: 'update',
	remove: 'remove',
	clear: 'clear',
	addChild: 'add_child',
	removeChild: 'remove_child',
	addBefore: 'add_before',
	addAfter: 'add_after',
};
