export { MainLayout } from './main-layout';
export { AltTextLayout } from './alt-text-layout';
export { ManualLayout } from './manual-layout';
export { ManageMainLayout } from './manage-main-layout';
export { RemediationLayout } from './remediation-layout';
